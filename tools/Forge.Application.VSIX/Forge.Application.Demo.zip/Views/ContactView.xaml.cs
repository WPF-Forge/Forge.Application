﻿namespace $safeprojectname$.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for ContactView.xaml
    /// </summary>
    public partial class ContactView : UserControl
    {
        public ContactView()
        {
            InitializeComponent();
        }
    }
}
