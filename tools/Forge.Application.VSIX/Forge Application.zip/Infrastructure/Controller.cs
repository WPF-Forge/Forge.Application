﻿using Forge.Application.Infrastructure;
using Forge.Application.Routing;
using $safeprojectname$.Routes;

namespace $safeprojectname$.Infrastructure
{
    public class Controller : AppController
    {
        protected override void OnInitializing()
        {
            var factory = this.Routes.RouteFactory;
            this.Routes.MenuRoutes.Add(this.InitialRoute = factory.Get<HomeRoute>());
        }
    }
}
